# Project Name

Project consis of two dataset, one for classification that is adult data and other is for regression that is houseprices data.

## Table of Contents

- [Database](#consist code where converted both preprocessed files to database and created two tables for each one)
- [DatabaseCollection](#consist information that from where and with which requirement data collected and sample of data for both files.)
- [DataProcessing](#consist of preprocessing steps to train the model to perform machine learning model)
- [Models](#consist of three model performing for each dataset to validate and test which performs best)
- [templates](#consist of four html files for website which are welcome page, about page, prediction page)

## Introduction

Its performing machine learning models 
one for classification which covering three models and calculating acc score
other for regression which covering three models and calculating rmse score

## Installation

for classification dataset, from provided link Source: Kaggle (link:"https://www.kaggle.com/datasets/lespin/house-prices-dataset) download data run code it will automatically created other files needed for next steps and run app.py file which will run on localhost:5000 and shows welcome page, about page and prediction page.


